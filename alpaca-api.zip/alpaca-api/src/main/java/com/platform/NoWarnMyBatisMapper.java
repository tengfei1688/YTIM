package com.platform;

import org.apache.ibatis.annotations.Mapper;

/**
 * 去除启动警告
 */
@Mapper
public interface NoWarnMyBatisMapper {
}
