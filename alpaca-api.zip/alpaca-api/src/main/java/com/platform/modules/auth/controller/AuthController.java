package com.platform.modules.auth.controller;

import cn.hutool.core.lang.Dict;
import com.platform.common.aspectj.SubmitRepeat;
import com.platform.common.aspectj.VersionRepeat;
import com.platform.common.web.controller.BaseController;
import com.platform.common.web.domain.AjaxResult;
import com.platform.common.web.version.VersionEnum;
import com.platform.modules.auth.service.AuthService;
import com.platform.modules.auth.vo.*;
import com.platform.modules.chat.service.ChatUserService;
import com.platform.modules.common.enums.MessageTypeEnum;
import com.platform.modules.common.service.MessageService;
import com.platform.modules.common.vo.CommonVo03;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * 认证
 */
@RestController
@Slf4j
@RequestMapping("/auth")
public class AuthController extends BaseController {

    @Resource
    private ChatUserService chatUserService;

    @Resource
    private MessageService messageService;

    @Resource
    private AuthService authService;

    /**
     * 发送短信（登录注册/忘记密码）
     */
    @VersionRepeat(VersionEnum.V1_0_0)
    @PostMapping(value = "/sendCode")
    @SubmitRepeat
    public AjaxResult sendCode(@Validated @RequestBody CommonVo03 commonVo) {
        Dict dict = chatUserService.sendCode(commonVo);
        return AjaxResult.success(dict);
    }

    /**
     * 登录方法（根据账号+密码登录）
     */
    @VersionRepeat(VersionEnum.V1_0_0)
    @PostMapping("/loginByPwd")
    @SubmitRepeat
    public AjaxResult loginByPwd(@Validated @RequestBody AuthVo02 authVo) {
        AuthVo00 data = authService.loginByPwd(authVo.getPhone(), authVo.getPassword());
        return AjaxResult.success(data);
    }

    /**
     * 登录方法（根据账号+验证码登录）
     */
    @VersionRepeat(VersionEnum.V1_0_0)
    @PostMapping("/loginByCode")
    @SubmitRepeat
    public AjaxResult loginByCode(@Validated @RequestBody AuthVo03 authVo) {
        // 验证
        messageService.verifySms(authVo.getPhone(), authVo.getCode(), MessageTypeEnum.LOGIN);
        // 执行登录
        AuthVo00 data = authService.loginByCode(authVo);
        return AjaxResult.success(data);
    }

    /**
     * 找回密码（根据账号）
     */
    @VersionRepeat(VersionEnum.V1_0_0)
    @PostMapping("/forget")
    public AjaxResult forget(@Validated @RequestBody AuthVo01 authVo) {
        // 验证
        String phone = authVo.getPhone();
        messageService.verifySms(phone, authVo.getCode(), MessageTypeEnum.FORGET);
        // 重置
        chatUserService.resetPass(phone, authVo.getPassword());
        return AjaxResult.success();
    }

    /**
     * 退出系统
     */
    @VersionRepeat(VersionEnum.V1_0_0)
    @GetMapping("/logout")
    public AjaxResult logout() {
        chatUserService.logout();
        return AjaxResult.success();
    }

    /**
     * 生成二维码
     */
    @VersionRepeat(VersionEnum.V1_0_0)
    @GetMapping("/getQrCode")
    public AjaxResult getQrCode() {
        // 调用
        AuthVo05 data = authService.getQrCode();
        return AjaxResult.success(data);
    }

    /**
     * 确认二维码
     */
    @VersionRepeat(VersionEnum.V1_0_0)
    @PostMapping("/confirmQrCode")
    public AjaxResult confirmQrCode(@Validated @RequestBody AuthVo04 authVo) {
        // 调用
        authService.confirmQrCode(authVo.getToken());
        return AjaxResult.success();
    }


}
