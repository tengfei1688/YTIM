package com.platform.modules.chat.domain;

import cn.hutool.core.util.NumberUtil;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.platform.common.core.EnumUtils;
import com.platform.common.enums.YesOrNoEnum;
import com.platform.common.web.domain.BaseEntity;
import com.platform.modules.chat.enums.ChatConfigEnum;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * <p>
 * 设置表实体类
 * </p>
 */
@Data
@TableName("chat_config")
@Accessors(chain = true) // 链式调用
public class ChatConfig extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * key
     */
    @TableId
    private ChatConfigEnum configKey;
    /**
     * value
     */
    private String configValue;

    public String getStr() {
        return configValue;
    }

    public Integer getInt() {
        return NumberUtil.parseInt(configValue);
    }

    public BigDecimal getBigDecimal() {
        return NumberUtil.toBigDecimal(configValue).setScale(2, BigDecimal.ROUND_HALF_DOWN);
    }

    public YesOrNoEnum getYesOrNo() {
        return EnumUtils.toEnum(YesOrNoEnum.class, configValue, YesOrNoEnum.NO);
    }

}
