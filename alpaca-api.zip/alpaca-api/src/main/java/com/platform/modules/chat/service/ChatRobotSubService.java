package com.platform.modules.chat.service;

import com.platform.modules.chat.domain.ChatRobotSub;
import com.platform.common.web.service.BaseService;

/**
 * <p>
 * 服务号 服务层
 * </p>
 */
public interface ChatRobotSubService extends BaseService<ChatRobotSub> {

}
