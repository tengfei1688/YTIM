package com.platform.modules.chat.tencent;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 腾讯nlp配置
 */
@Component
@Data
public class TencentConfig {

    @Value("${tencent.status}")
    private String status;

    @Value("${tencent.appId}")
    private String appId;

    @Value("${tencent.accessKey}")
    private String accessKey;

    @Value("${tencent.secretKey}")
    private String secretKey;

}