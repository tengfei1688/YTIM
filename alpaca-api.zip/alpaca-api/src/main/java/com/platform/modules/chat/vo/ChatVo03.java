package com.platform.modules.chat.vo;

import cn.hutool.json.JSONObject;
import com.platform.modules.push.enums.PushMsgTypeEnum;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;

@Data
@Accessors(chain = true) // 链式调用
public class ChatVo03 {

    @NotNull(message = "消息ID不能为空")
    private Long msgId;

    @NotNull(message = "同步ID不能为空")
    private Long syncId;

    @NotNull(message = "用户不能为空")
    private Long robotId;

    @NotNull(message = "消息类型不能为空")
    private PushMsgTypeEnum msgType;

    @NotNull(message = "消息内容不能为空")
    private JSONObject content;

}
