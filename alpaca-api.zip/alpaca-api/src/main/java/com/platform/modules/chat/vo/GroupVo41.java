package com.platform.modules.chat.vo;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true) // 链式调用
public class GroupVo41 {

    /**
     * 接龙ID
     */
    private Long solitaireId;

}
