package com.platform.modules.chat.vo;

import com.platform.common.enums.GenderEnum;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class MineVo05 {

    @NotNull(message = "性别不能为空")
    private GenderEnum gender;

}
