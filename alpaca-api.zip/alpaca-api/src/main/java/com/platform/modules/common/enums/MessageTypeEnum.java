package com.platform.modules.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/**
 * 短信类型枚举
 */
@Getter
public enum MessageTypeEnum {

    /**
     * 登录/注册
     */
    LOGIN("1", "chat:code:login:", 5),
    /**
     * 忘记登录密码
     */
    FORGET("2", "chat:code:forget:", 5),
    /**
     * 钱包
     */
    WALLET("3", "chat:code:wallet:", 5),
    /**
     * 绑定
     */
    BINDING("4", "chat:code:binding:", 5),
    ;

    @EnumValue
    @JsonValue
    private String code;
    private String prefix;
    private Integer timeout;

    MessageTypeEnum(String code, String prefix, Integer timeout) {
        this.code = code;
        this.prefix = prefix;
        this.timeout = timeout;
    }

}
